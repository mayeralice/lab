#pragma once

#include "ACmdReceiver.h"

class FooCmdReceiver : public ACmdReceiver {
public:
    std::string receive() override;
};
