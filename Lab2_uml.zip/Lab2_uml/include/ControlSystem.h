#pragma once

#include <sstream>
#include <string>

class AEngine;
class ACmdReceiver;

class ControlSystem {
public:
    ControlSystem(AEngine& engine, ACmdReceiver& receiver);

    bool run();

private:
    void parseMessage(const std::string& msg, std::istringstream& iss);

    AEngine& engine_;
    ACmdReceiver& receiver_;
};
