#pragma once

#include "AEngine.h"

class FooEngine : public AEngine {
public:
    void forward(int time_ms) override;
    void right(int time_ms) override;
    void left(int time_ms) override;
    void stop() override;
};
