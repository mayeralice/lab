#include "ControlSystem.h"
#include "FooCmdReceiver.h"
#include "FooEngine.h"

#include <iostream>

int main() {
    FooEngine engine;
    FooCmdReceiver receiver;
    ControlSystem control(engine, receiver);

    std::cout << "forward, right, left, stop. Выход: quit" << std::endl;

    while (control.run()) {
    }

    return 0;
}
