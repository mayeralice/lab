#include "FooEngine.h"

#include <chrono>
#include <iostream>
#include <thread>

namespace {

void simulate(const char* action, int time_ms) {
    std::cout << action << std::endl;
    std::this_thread::sleep_for(std::chrono::milliseconds(time_ms));
}

}  // namespace

void FooEngine::forward(int time_ms) {
    simulate("forward", time_ms);
}

void FooEngine::right(int time_ms) {
    simulate("right", time_ms);
}

void FooEngine::left(int time_ms) {
    simulate("left", time_ms);
}

void FooEngine::stop() {
    std::cout << "stop" << std::endl;
}
