#include "FooCmdReceiver.h"

#include <iostream>

std::string FooCmdReceiver::receive() {
    std::string line;
    std::getline(std::cin, line);
    return line;
}
