#include "ControlSystem.h"

#include "ACmdReceiver.h"
#include "AEngine.h"

#include <climits>
#include <iostream>
#include <sstream>

namespace {

int readTimeMs(std::istringstream& iss) {
    long long time_ms = 0;
    if (iss >> time_ms) {
        if (time_ms < 0 || time_ms > INT_MAX) {
            std::cout << "Неверное время" << std::endl;
            return -1;
        }
        return static_cast<int>(time_ms);
    }

    std::cout << "> ";
    if (!(std::cin >> time_ms)) {
        return -1;
    }
    if (time_ms < 0 || time_ms > INT_MAX) {
        std::cout << "Неверное время" << std::endl;
        return -1;
    }
    return static_cast<int>(time_ms);
}

}  // namespace

ControlSystem::ControlSystem(AEngine& engine, ACmdReceiver& receiver)
    : engine_(engine), receiver_(receiver) {}

bool ControlSystem::run() {
    const std::string line = receiver_.receive();
    if (line.empty()) {
        return true;
    }

    std::cout << line << std::endl;

    std::istringstream iss(line);
    std::string msg;
    iss >> msg;

    if (msg == "quit" || msg == "exit") {
        return false;
    }

    parseMessage(msg, iss);
    return true;
}

void ControlSystem::parseMessage(const std::string& msg, std::istringstream& iss) {
    if (msg == "stop") {
        engine_.stop();
        return;
    }

    if (msg == "forward" || msg == "right" || msg == "left") {
        const int time_ms = readTimeMs(iss);
        if (time_ms < 0) {
            return;
        }

        if (msg == "forward") {
            engine_.forward(time_ms);
        } else if (msg == "right") {
            engine_.right(time_ms);
        } else {
            engine_.left(time_ms);
        }
        return;
    }

    std::cout << "Неизвестная команда: " << msg << std::endl;
}
