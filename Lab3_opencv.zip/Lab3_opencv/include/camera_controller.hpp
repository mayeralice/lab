#pragma once

#include <opencv2/videoio.hpp>

class CameraController {
public:
    explicit CameraController(int cameraId = 0);

    bool open();
    bool getFrame(cv::Mat& frame);
    void release();

    bool isOpened() const { return isOpened_; }

private:
    int cameraId_;
    cv::VideoCapture capture_;
    bool isOpened_{false};
};
