#pragma once

#include <opencv2/core.hpp>
#include <string>

class Visualizer {
public:
    static void drawRectangle(cv::Mat& image, const cv::Rect& rectangle,
                              const cv::Scalar& color = cv::Scalar(0, 255, 0),
                              int thickness = 2);

    static void drawCenter(cv::Mat& image, const cv::Point& center,
                           const cv::Scalar& color = cv::Scalar(0, 0, 255),
                           int radius = 5);

    static void drawLineToCenter(cv::Mat& image, const cv::Point& point,
                                 const cv::Point& imageCenter,
                                 const cv::Scalar& color = cv::Scalar(255, 0, 0));

    static void putText(cv::Mat& image, const std::string& text,
                        const cv::Point& position,
                        const cv::Scalar& color = cv::Scalar(255, 255, 255));
};
