#pragma once

#include "camera_controller.hpp"
#include "contrast_object_detector.hpp"
#include "object_analyzer.hpp"
#include "visualizer.hpp"

#include <opencv2/core.hpp>
#include <string>
#include <vector>

struct TrackedObject {
    int id{};
    cv::Point center;
    cv::Rect rectangle;
    double angle{};
    double distance{};
    std::vector<cv::Point> contour;
};

struct FrameResults {
    std::vector<TrackedObject> objects;
    cv::Point imageCenter;
    int numObjects{};
};

class ObjectTrackingSystem {
public:
    ObjectTrackingSystem(int cameraId = 0,
                         double targetWidthCm = 10.0,
                         bool invertDetection = true);

    void run();

private:
    void sendRobotCommand(const std::string& command);

    cv::Point getImageCenter(const cv::Mat& image) const;
    FrameResults processFrame(cv::Mat& frame);

    CameraController camera_;
    ContrastObjectDetector detector_;
    ObjectAnalyzer analyzer_;
    double targetWidthCm_;
    int frameCount_{0};
    bool invertDetection_;
};
