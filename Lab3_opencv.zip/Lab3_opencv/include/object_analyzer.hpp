#pragma once

#include <opencv2/core.hpp>
#include <utility>

class ObjectAnalyzer {
public:
    static constexpr double IPHONE14_FOCAL_LENGTH = 2713.0;

    explicit ObjectAnalyzer(double realWidth = 10.0);

    cv::Point calculateCenterOfMass(const std::vector<cv::Point>& contour) const;
    double calculateAngleToTarget(const cv::Point& center,
                                  const cv::Point& imageCenter,
                                  double fovX = 67.0,
                                  int imageWidth = 1920) const;
    double calculateDistance(const cv::Rect& rectangle) const;

private:
    double focalLength_;
    double realWidth_;
};
