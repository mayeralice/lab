#pragma once

#include <opencv2/core.hpp>
#include <vector>

class ContrastObjectDetector {
public:
    ContrastObjectDetector(int threshold = 50, int minArea = 500, bool invert = true);

    cv::Mat preprocessImage(const cv::Mat& image) const;
    std::vector<std::vector<cv::Point>> findContours(const cv::Mat& binaryImage) const;
    std::vector<cv::Rect> getBoundingRectangles(
        const std::vector<std::vector<cv::Point>>& contours) const;

    void detectObjects(const cv::Mat& image,
                       std::vector<std::vector<cv::Point>>& contours,
                       std::vector<cv::Rect>& rectangles) const;

    int threshold;
    int minArea;
    bool invert;
};
