#include "visualizer.hpp"

#include <opencv2/imgproc.hpp>

void Visualizer::drawRectangle(cv::Mat& image, const cv::Rect& rectangle,
                               const cv::Scalar& color, int thickness) {
    cv::rectangle(image, rectangle, color, thickness);
}

void Visualizer::drawCenter(cv::Mat& image, const cv::Point& center,
                            const cv::Scalar& color, int radius) {
    cv::circle(image, center, radius, color, -1);
}

void Visualizer::drawLineToCenter(cv::Mat& image, const cv::Point& point,
                                  const cv::Point& imageCenter,
                                  const cv::Scalar& color) {
    cv::line(image, point, imageCenter, color, 2);
}

void Visualizer::putText(cv::Mat& image, const std::string& text,
                         const cv::Point& position, const cv::Scalar& color) {
    cv::putText(image, text, position, cv::FONT_HERSHEY_SIMPLEX, 0.6, color, 2);
}
