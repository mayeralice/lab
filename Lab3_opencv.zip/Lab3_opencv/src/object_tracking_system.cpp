#include "object_tracking_system.hpp"

#include <opencv2/highgui.hpp>

#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <sstream>

namespace {
constexpr const char* kRobotHost = "user@192.168.1.101";
constexpr const char* kRobotScript = "~/lab5/robot";
}  // namespace

ObjectTrackingSystem::ObjectTrackingSystem(int cameraId,
                                           double targetWidthCm,
                                           bool invertDetection)
    : camera_(cameraId),
      detector_(100, 500, invertDetection),
      analyzer_(targetWidthCm),
      targetWidthCm_(targetWidthCm),
      invertDetection_(invertDetection) {}

void ObjectTrackingSystem::sendRobotCommand(const std::string& command) {
    char cmd[256];
    std::snprintf(cmd, sizeof(cmd),
                  "ssh %s '%s %s' > /dev/null 2>&1 &",
                  kRobotHost, kRobotScript, command.c_str());
    std::system(cmd);
    std::cout << "[CMD] " << cmd << std::endl;
}

cv::Point ObjectTrackingSystem::getImageCenter(const cv::Mat& image) const {
    return {image.cols / 2, image.rows / 2};
}

FrameResults ObjectTrackingSystem::processFrame(cv::Mat& frame) {
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Rect> rectangles;
    detector_.detectObjects(frame, contours, rectangles);

    FrameResults results;
    results.imageCenter = getImageCenter(frame);
    results.numObjects = static_cast<int>(contours.size());
    results.objects.reserve(contours.size());

    for (size_t i = 0; i < contours.size(); ++i) {
        const cv::Point center = analyzer_.calculateCenterOfMass(contours[i]);
        const double angle = analyzer_.calculateAngleToTarget(
            center, results.imageCenter, 60.0, frame.cols);
        const double distance = analyzer_.calculateDistance(rectangles[i]);

        TrackedObject obj;
        obj.id = static_cast<int>(i);
        obj.center = center;
        obj.rectangle = rectangles[i];
        obj.angle = angle;
        obj.distance = distance;
        obj.contour = contours[i];
        results.objects.push_back(obj);

        Visualizer::drawRectangle(frame, rectangles[i]);
        Visualizer::drawCenter(frame, center);
        Visualizer::drawLineToCenter(frame, center, results.imageCenter);

        const cv::Scalar textColor =
            invertDetection_ ? cv::Scalar(0, 255, 255) : cv::Scalar(0, 255, 0);

        std::ostringstream oss;
        oss << "Obj " << i << ": angle=" << std::fixed << std::setprecision(1)
            << angle << " deg, dist=" << distance << " cm";

        const cv::Point textPos(rectangles[i].x, rectangles[i].y - 10);
        Visualizer::putText(frame, oss.str(), textPos, textColor);
    }

    if (results.numObjects > 0) {
        TrackedObject& obj = results.objects[0];

        if (std::abs(obj.angle) > 10.0) {
            if (obj.angle > 0) {
                sendRobotCommand("right 300");
                std::cout << "[DECISION] Поворот направо на 300 мс" << std::endl;
            } else {
                sendRobotCommand("left 300");
                std::cout << "[DECISION] Поворот налево на 300 мс" << std::endl;
            }
        } else if (obj.distance > 30.0) {
            const int duration = static_cast<int>(obj.distance * 1.5);
            sendRobotCommand("forward " + std::to_string(duration));
            std::cout << "[DECISION] Ехать вперёд " << duration << " мс" << std::endl;
        } else {
            sendRobotCommand("stop");
            std::cout << "[DECISION] Цель достигнута, остановка" << std::endl;
        }
    }

    return results;
}

void ObjectTrackingSystem::run() {
    if (!camera_.open()) {
        std::cerr << "Ошибка: Не удалось открыть камеру\n";
        return;
    }

    const char* mode = invertDetection_
                           ? "тёмные объекты (чёрный на белом)"
                           : "светлые объекты (белый на чёрном)";

    std::cout << "Система запущена. Режим: " << mode << "\n";
    std::cout << "Нажмите 'q' для выхода\n";
    std::cout << "Нажмите 'i' для инверсии режима обнаружения\n";
    std::cout << std::string(60, '-') << "\n";

    while (true) {
        cv::Mat frame;
        if (!camera_.getFrame(frame) || frame.empty()) {
            continue;
        }

        cv::Mat displayFrame = frame.clone();
        const FrameResults results = processFrame(displayFrame);

        ++frameCount_;
        if (frameCount_ % 30 == 0 && results.numObjects > 0) {
            std::cout << "\n--- Кадр " << frameCount_ << " ---\n";
            for (const auto& obj : results.objects) {
                std::cout << "Объект " << obj.id << ": расстояние = " << std::fixed
                          << std::setprecision(1) << obj.distance
                          << " см, угол = " << std::showpos << obj.angle << " град"
                          << std::noshowpos << "\n";
            }
            std::cout << std::string(40, '-') << "\n";
        }

        const std::string modeLabel = invertDetection_ ? "Dark" : "Light";
        const std::string infoText =
            "Objects: " + std::to_string(results.numObjects) + " | Mode: " + modeLabel;
        Visualizer::putText(displayFrame, infoText, {10, 30});

        cv::imshow("Object Tracking", displayFrame);

        const int key = cv::waitKey(1) & 0xFF;
        if (key == 'q' || key == 'Q') {
            break;
        }
        if (key == 'i' || key == 'I') {
            invertDetection_ = !invertDetection_;
            detector_.invert = invertDetection_;
            const char* newMode = invertDetection_ ? "тёмные" : "светлые";
            std::cout << "\nРежим изменён на: поиск " << newMode << " объектов\n";
        }
    }

    camera_.release();
    cv::destroyAllWindows();
    std::cout << "\nСистема остановлена\n";
}
