#include "object_analyzer.hpp"

#include <opencv2/imgproc.hpp>

ObjectAnalyzer::ObjectAnalyzer(double realWidth)
    : focalLength_(IPHONE14_FOCAL_LENGTH), realWidth_(realWidth) {}

cv::Point ObjectAnalyzer::calculateCenterOfMass(
    const std::vector<cv::Point>& contour) const {
    const cv::Moments moments = cv::moments(contour);
    if (moments.m00 != 0.0) {
        const int cx = static_cast<int>(moments.m10 / moments.m00);
        const int cy = static_cast<int>(moments.m01 / moments.m00);
        return {cx, cy};
    }

    const cv::Rect rect = cv::boundingRect(contour);
    return {rect.x + rect.width / 2, rect.y + rect.height / 2};
}

double ObjectAnalyzer::calculateAngleToTarget(const cv::Point& center,
                                              const cv::Point& imageCenter,
                                              double fovX,
                                              int imageWidth) const {
    const int offsetX = center.x - imageCenter.x;
    return (static_cast<double>(offsetX) / imageWidth) * fovX;
}

double ObjectAnalyzer::calculateDistance(const cv::Rect& rectangle) const {
    if (rectangle.width > 0) {
        return 5000.0 / rectangle.width;
    }
    return 0.0;
}
