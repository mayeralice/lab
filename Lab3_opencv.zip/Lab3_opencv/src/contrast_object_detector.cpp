#include "contrast_object_detector.hpp"

#include <opencv2/imgproc.hpp>

ContrastObjectDetector::ContrastObjectDetector(int threshold, int minArea, bool invert)
    : threshold(threshold), minArea(minArea), invert(invert) {}

cv::Mat ContrastObjectDetector::preprocessImage(const cv::Mat& image) const {
    cv::Mat gray;
    cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);

    cv::Mat blurred;
    cv::GaussianBlur(gray, blurred, cv::Size(5, 5), 0);

    cv::Mat binary;
    const int threshType = invert ? cv::THRESH_BINARY_INV : cv::THRESH_BINARY;
    cv::threshold(blurred, binary, threshold, 255, threshType);

    return binary;
}

std::vector<std::vector<cv::Point>> ContrastObjectDetector::findContours(
    const cv::Mat& binaryImage) const {
    std::vector<std::vector<cv::Point>> contours;
    cv::findContours(binaryImage, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    std::vector<std::vector<cv::Point>> filtered;
    filtered.reserve(contours.size());
    for (const auto& cnt : contours) {
        if (cv::contourArea(cnt) >= minArea) {
            filtered.push_back(cnt);
        }
    }
    return filtered;
}

std::vector<cv::Rect> ContrastObjectDetector::getBoundingRectangles(
    const std::vector<std::vector<cv::Point>>& contours) const {
    std::vector<cv::Rect> rectangles;
    rectangles.reserve(contours.size());
    for (const auto& contour : contours) {
        rectangles.push_back(cv::boundingRect(contour));
    }
    return rectangles;
}

void ContrastObjectDetector::detectObjects(const cv::Mat& image,
                                           std::vector<std::vector<cv::Point>>& contours,
                                           std::vector<cv::Rect>& rectangles) const {
    const cv::Mat binary = preprocessImage(image);
    contours = findContours(binary);
    rectangles = getBoundingRectangles(contours);
}
