#include "camera_controller.hpp"

CameraController::CameraController(int cameraId)
    : cameraId_(cameraId) {}

bool CameraController::open() {
    capture_.open(cameraId_);
    isOpened_ = capture_.isOpened();
    return isOpened_;
}

bool CameraController::getFrame(cv::Mat& frame) {
    if (!isOpened_) {
        return false;
    }
    return capture_.read(frame);
}

void CameraController::release() {
    if (capture_.isOpened()) {
        capture_.release();
    }
    isOpened_ = false;
}
