#include "object_tracking_system.hpp"

int main() {
    // invertDetection=true  — ищем ТЁМНЫЕ объекты (чёрный на белом)
    // invertDetection=false — ищем СВЕТЛЫЕ объекты (белый на чёрном)
    ObjectTrackingSystem system(0, 10.0, true);
    system.run();
    return 0;
}
